<style lang="sass">
$text-color: red

.red
  color: $text-color
</style>
<template>
<router-link to="/components" class="red">Hello Sass</router-link>
</template>
