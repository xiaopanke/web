<style lang="scss" scoped>
@import '../assets/css/reset.css';

.fixBg { width: 100%; height: 100%; position: fixed; top: 0; left: 0; background-color: #000; opacity: 0.8; z-index: 10; }
</style>
<template>
<div class='fixBg'></div>
</template>
<script>
export default {
  data () {
    return {
    }
  },
  components: {
  },
  methods: {
  },
  mounted () {
  }
}
</script>
