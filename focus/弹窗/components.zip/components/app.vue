<style>
.app {
  text-align: center;
}
</style>

<template>
<div class="app">
  <index/>
</div>
</template>

<script>
import Index from 'components/index'

export default {
  components: {
    index: Index
  }
}
</script>
