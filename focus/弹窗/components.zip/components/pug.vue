<template lang="pug">
div Hello Pug3
</template>
